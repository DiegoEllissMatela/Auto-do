"""Auto Do Application Package"""
__version__ = "2.4.0"
